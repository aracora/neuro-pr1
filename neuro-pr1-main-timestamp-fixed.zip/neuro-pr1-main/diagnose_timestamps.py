#!/usr/bin/env python
"""Быстрая диагностика поля Timestamp без загрузки всего датасета в память.

python diagnose_timestamps.py --raw data/raw --sample 100000
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

from preprocess_node1 import _timestamp_seconds


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--raw', type=Path, default=Path('data/raw'))
    parser.add_argument('--sample', type=int, default=100000, help='Число первых строк для проверки каждого CSV')
    parser.add_argument('--window', type=float, default=2.0)
    parser.add_argument('--timestamp-unit', choices=['auto','s','ms','us','ns','excel-d'], default='auto')
    args = parser.parse_args()
    files = sorted(args.raw.glob('*.csv'))
    if not files:
        raise SystemExit(f'Нет CSV в {args.raw}')
    for path in files:
        print(f'\n==== {path.name} ====')
        try:
            df = pd.read_csv(path, nrows=args.sample, usecols=lambda c: str(c).strip() == 'Timestamp', low_memory=False)
            df.columns = df.columns.str.strip()
            print('Примеры исходных Timestamp:', df['Timestamp'].head(8).tolist())
            print('Прочитано:', len(df), 'Уникальных исходных Timestamp:', df['Timestamp'].nunique())
            sec = _timestamp_seconds(df, args.timestamp_unit)
            sec = sec[np.isfinite(sec)]
            windows = np.floor(sec / args.window).astype(np.int64)
            print('Диапазон времени (сек):', round(float(sec.max() - sec.min()), 6))
            print('Различных окон в прочитанных строках:', len(np.unique(windows)))
            unique_sec = np.unique(sec)
            if len(unique_sec)>1:
                diff = np.diff(unique_sec)
                print('Минимальный ненулевой шаг Timestamp (сек):', round(float(np.min(diff)), 9))
        except Exception as e:
            print('Ошибка:', e)

if __name__ == '__main__':
    main()
