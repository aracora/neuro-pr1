"""Корректная оценка оконных моделей по отдельным сетевым потокам (flow).

Одна модель предсказывает класс окна, затем предсказание распространяется
на все flow в этом окне. Каждая строка тестового parquet учитывается один раз.
Проценты нормализуются ПО СТРОКАМ (по истинному классу).
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix


def predictions_per_flow(df: pd.DataFrame, window_ids, predictions, truth_col="label"):
    """Возвращает метки каждого flow и соответствующий прогноз его окна.

    Для одного window_id должна быть ровно одна prediction; неизвестные id — ошибка.
    """
    window_ids = list(window_ids)
    pred = np.asarray(predictions, dtype=np.int64)
    if len(window_ids) != len(pred) or len(set(window_ids)) != len(window_ids):
        raise ValueError("window_ids и predictions должны быть одинаковой длины и уникальны")
    prediction_map = pd.Series(pred, index=pd.Index(window_ids))
    if not df["window_id"].isin(prediction_map.index).all():
        missing = df.loc[~df["window_id"].isin(prediction_map.index), "window_id"].unique()
        raise ValueError(f"Не найдены предсказания для {len(missing)} окон")
    return (df[truth_col].to_numpy(dtype=np.int64),
            df["window_id"].map(prediction_map).to_numpy(dtype=np.int64))


def normalized_confusion(y_true, y_pred, classes_ru, path, title, cmap="Blues"):
    """Сохраняет только НОРМАЛИЗОВАННУЮ матрицу; подписи в процентах.

    При отсутствии примеров класса строка остаётся нулевой (не подменяется 100%).
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    classes = list(range(len(classes_ru)))
    cm = confusion_matrix(y_true, y_pred, labels=classes)
    totals = cm.sum(axis=1, keepdims=True)
    proportions = np.divide(cm, totals, out=np.zeros_like(cm, dtype=float), where=totals != 0)
    pct = 100.0 * proportions
    size = max(6, 1.2 * len(classes_ru))
    fig, ax = plt.subplots(figsize=(size + 0.8, size * 0.85))
    sns.heatmap(pct, annot=True, fmt=".1f", vmin=0, vmax=100, cmap=cmap,
                xticklabels=classes_ru, yticklabels=classes_ru,
                cbar_kws={"label": "Доля потоков, %"}, ax=ax)
    ax.set_xlabel("Предсказанный класс")
    ax.set_ylabel("Истинный класс")
    n = len(y_true)
    correct = int(np.count_nonzero(y_true == y_pred))
    ax.set_title(f"{title}\nПо flow: {correct:,} из {n:,} верно ({correct / n:.1%})" if n else title)
    ax.tick_params(axis="x", labelrotation=35)
    for label in ax.get_xticklabels(): label.set_horizontalalignment("right")
    fig.tight_layout()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return cm


def remove_old_plots(directory, prefix):
    """Убирает старые loss и ненормализованные matrix PNG от прежних запусков."""
    directory = Path(directory)
    for suffix in ("_loss.png", "_confusion_matrix.png"):
        (directory / f"{prefix}{suffix}").unlink(missing_ok=True)
