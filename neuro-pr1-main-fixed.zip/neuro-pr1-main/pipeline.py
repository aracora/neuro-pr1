#!/usr/bin/env python
"""Двухузловой пайплайн: Узел 1 (Бинарный) + Узел 2 (Мультиклассовый)."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

# Импорты из наших скриптов
from labels_node1 import CLASS_NAMES_RU as NAMES_1, NODE1_CLASSES as CLS_1
from labels_node2 import CLASS_NAMES_RU as NAMES_2, NODE1_CLASSES as CLS_2
from window_features import aggregate_windows, feature_columns
from traffic_metrics import normalized_confusion, predictions_per_flow, remove_old_plots

# Для Узла 1
from node1_lstm_1 import LSTMClassifier as LSTM1, build_vocab, make_sequences as make_seq1, SequenceDataset as SeqDs1, SequenceCollator as SeqColl1
from node1_mlp_1 import MLPClassifier as MLP1

# Для Узла 2
from node1_lstm_2 import LSTMClassifier as LSTM2, make_sequences as make_seq2, SequenceDataset as SeqDs2, SequenceCollator as SeqColl2
from node1_mlp_2 import MLPClassifier as MLP2

import lightgbm as lgb

SEED = 42
PROCESSED_1 = Path("data/processed_node1")
PROCESSED_2 = Path("data/processed_node2")
MODELS = Path("models")
OUT_DIR = Path("pipeline_results")
OUT_DIR.mkdir(exist_ok=True)

def get_lstm_probs(ckpt_dir, test_df, LSTMClass, make_seq_fn, SeqDs, SeqColl):
    device = torch.device("cpu")
    ckpt = torch.load(ckpt_dir / "model.pt", map_location=device, weights_only=False)
    numeric_cols = ckpt["numeric_cols"]
    src_vocab = {int(k): int(v) for k, v in ckpt["src_vocab"].items()}
    dst_vocab = {int(k): int(v) for k, v in ckpt["dst_vocab"].items()}
    proto_vocab = {int(k): int(v) for k, v in ckpt["protocol_vocab"].items()}

    scaler = StandardScaler()
    scaler.mean_ = np.array(ckpt["scaler_mean"])
    scaler.scale_ = np.array(ckpt["scaler_scale"])
    scaler.var_ = scaler.scale_ ** 2
    scaler.n_features_in_ = len(numeric_cols)

    seqs, labels = make_seq_fn(test_df, numeric_cols, scaler, src_vocab, dst_vocab, proto_vocab)
    model = LSTMClass(n_numeric=len(numeric_cols), src_cardinality=len(src_vocab) + 1,
                      dst_cardinality=len(dst_vocab) + 1, protocol_cardinality=len(proto_vocab) + 1).to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()

    loader = DataLoader(SeqDs(seqs, labels), batch_size=64, shuffle=False, collate_fn=SeqColl())
    probs_list = []
    with torch.no_grad():
        for num, src, dst, proto, lengths, y in loader:
            logits = model(num, src, dst, proto, lengths)
            probs_list.append(F.softmax(logits, dim=-1).numpy())
    return np.concatenate(probs_list)

def get_mlp_probs(ckpt_dir, agg_df, MLPClass, feat_cols):
    device = torch.device("cpu")
    ckpt = torch.load(ckpt_dir / "model.pt", map_location=device, weights_only=False)
    X = agg_df[feat_cols].to_numpy(dtype=np.float32)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    
    scaler = StandardScaler()
    scaler.mean_ = np.array(ckpt["scaler_mean"])
    scaler.scale_ = np.array(ckpt["scaler_scale"])
    scaler.var_ = scaler.scale_ ** 2
    scaler.n_features_in_ = X.shape[1]
    X = scaler.transform(X).astype(np.float32)

    model = MLPClass(n_features=X.shape[1], n_classes=len(ckpt["classes"])).to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    
    with torch.no_grad():
        probs = F.softmax(model(torch.from_numpy(X).to(device)), dim=-1).numpy()
    return probs

def main():
    print("=== ДВУХУЗЛОВОЙ ПАЙПЛАЙН: КЛАССИФИКАЦИЯ КАЖДОГО FLOW ===")
    # Общая тестовая выборка взята ТОЛЬКО из первого узла.
    # attack_type сохраняет исходный тип атаки и для ошибок первого узла.
    test_df = pd.read_parquet(PROCESSED_1 / "test.parquet")
    if "attack_type" not in test_df.columns:
        raise RuntimeError("Отсутствует attack_type. Перезапустите preprocess_node1.py "
                           "и preprocess_node2.py из исправленного проекта")
    n_flows = len(test_df)
    print(f"Test: {n_flows:,} flow; {test_df['window_id'].nunique():,} окон")
    with open(PROCESSED_1 / "feature_names.json", encoding="utf-8") as f:
        features = json.load(f)
    cat_cols = ["Source Port", "Destination Port", "Protocol"]
    num_cols = [c for c in features if c not in cat_cols]
    agg = aggregate_windows(test_df, num_cols, cat_cols)
    with open(MODELS / "node1_lgbm_1" / "feature_columns.json", encoding="utf-8") as f:
        feat_cols = json.load(f)
    if not all(f in agg for f in feat_cols):
        raise RuntimeError("Не совпадают признаки models и предобработки; переобучите модели")
    window_ids = agg["window_id"].tolist()
    X = np.nan_to_num(agg[feat_cols].to_numpy(dtype=np.float32),
                      nan=0.0, posinf=0.0, neginf=0.0)

    # УЗЕЛ 1 — прогноз окна: 0 = нормальный, 1 = атака.
    print("\n[Узел 1] MLP + LightGBM: BENIGN vs ATTACK")
    p_mlp_1 = get_mlp_probs(MODELS / "node1_mlp_1", agg, MLP1, feat_cols)
    booster_1 = lgb.Booster(model_file=str(MODELS / "node1_lgbm_1" / "model.txt"))
    p_lgbm_1 = np.asarray(booster_1.predict(X))
    if p_lgbm_1.ndim == 1:
        p_lgbm_1 = np.stack([1 - p_lgbm_1, p_lgbm_1], axis=1)
    pred1 = ((p_mlp_1 + p_lgbm_1) / 2).argmax(axis=1)
    truth1_flow, pred1_flow = predictions_per_flow(test_df, window_ids, pred1)
    print(f"Правильно выявлено flow: {(truth1_flow == pred1_flow).sum():,} / {n_flows:,}")
    print(f"Accuracy: {accuracy_score(truth1_flow, pred1_flow):.4f}; "
          f"macro-F1: {f1_score(truth1_flow, pred1_flow, labels=[0,1], average='macro', zero_division=0):.4f}")
    normalized_confusion(truth1_flow, pred1_flow, NAMES_1,
        OUT_DIR / "pipeline_node1_confusion_matrix_normalized.png", "Узел 1 — по flow")

    # УЗЕЛ 2 — предсказывает ТОЛЬКО окна, которые Узел 1 назвал атакой.
    # Признаки вычисляются из ТОГО ЖЕ окна исходного test.parquet;
    # ложные срабатывания первого узла не пропадают из финальной метрики.
    attack_indices = np.flatnonzero(pred1 == 1)
    pred2_by_window = {}
    if len(attack_indices):
        print("\n[Узел 2] MLP + LightGBM: тип атаки")
        attack_agg = agg.iloc[attack_indices].reset_index(drop=True)
        X_2 = X[attack_indices]
        p_mlp_2 = get_mlp_probs(MODELS / "node1_mlp_2", attack_agg, MLP2, feat_cols)
        booster_2 = lgb.Booster(model_file=str(MODELS / "node1_lgbm_2" / "model.txt"))
        p_lgbm_2 = np.asarray(booster_2.predict(X_2))
        if p_lgbm_2.ndim == 1:
            raise RuntimeError("Второй узел должен возвращать вероятности пяти классов")
        pred2 = ((p_mlp_2 + p_lgbm_2) / 2).argmax(axis=1)
        pred2_by_window = dict(zip(attack_agg["window_id"], pred2.tolist()))
        # Оценка второго узла — только для ИСТИННЫХ атак, направленных в него.
        routed = test_df.loc[(test_df["label"] == 1) &
                             (test_df["window_id"].isin(pred2_by_window))]
        if not routed.empty:
            y_true2, y_pred2 = predictions_per_flow(routed, list(pred2_by_window),
                                                    list(pred2_by_window.values()), truth_col="attack_type")
            print(f"Правильно определено атакующих flow: {(y_true2 == y_pred2).sum():,} / {len(y_true2):,}")
            print(f"Accuracy: {accuracy_score(y_true2, y_pred2):.4f}; "
                  f"macro-F1: {f1_score(y_true2, y_pred2, labels=list(range(len(CLS_2))), average='macro', zero_division=0):.4f}")
            normalized_confusion(y_true2, y_pred2, NAMES_2,
                OUT_DIR / "pipeline_node2_confusion_matrix_normalized.png",
                "Узел 2 — истинные атаки, направленные на классификацию", cmap="Oranges")
        else:
            print("Истинные атаки не поступили во второй узел")
    else:
        print("\nУзел 1 не нашел атакующих окон; итоговые ошибки будут учтены.")

    # ОБЩИЙ РЕЗУЛЬТАТ: каждый flow присутствует РОВНО ОДИН РАЗ.
    # 0 = benign, 1..5 = классы атак; FN первого узла остаются FN в итоговой матрице.
    y_true_final = np.where(test_df["attack_type"].to_numpy(dtype=np.int64) < 0,
                            0, test_df["attack_type"].to_numpy(dtype=np.int64) + 1)
    pred_final = np.array([0 if stage1_prediction == 0 else int(pred2_by_window[win]) + 1
                           for win, stage1_prediction in zip(
                               test_df["window_id"], pred1_flow)], dtype=np.int64)
    final_classes = ["Нормальный трафик"] + NAMES_2
    print("\n=== ИТОГ ПО ВСЕМ FLOW ===")
    print(f"Верно: {(y_true_final == pred_final).sum():,} из {n_flows:,} "
          f"({accuracy_score(y_true_final, pred_final):.2%})")
    print(classification_report(y_true_final, pred_final,
                                labels=list(range(len(final_classes))),
                                target_names=final_classes, zero_division=0))
    remove_old_plots(OUT_DIR, "pipeline")
    cm = normalized_confusion(y_true_final, pred_final, final_classes,
        OUT_DIR / "pipeline_confusion_matrix_normalized.png", "Двухузловая система — по всем flow")
    (OUT_DIR / "metrics.json").write_text(json.dumps({
        "evaluation_unit": "flow", "test_flows": n_flows,
        "test_windows": int(len(window_ids)),
        "flow_accuracy": float(accuracy_score(y_true_final, pred_final)),
        "flow_macro_f1": float(f1_score(y_true_final, pred_final,
                                       labels=list(range(len(final_classes))),
                                       average="macro", zero_division=0)),
        "correct_flows": int((y_true_final == pred_final).sum()),
        "confusion_matrix_counts": cm.tolist(),
        "classes": final_classes,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Матрицы сохранены в {OUT_DIR} (только нормализованные, в %)")


if __name__ == "__main__":
    main()
