#!/usr/bin/env python
"""Ансамбль LightGBM + MLP + BiLSTM для Узла 1 И Узла 2.

Выбор метода производится по validation (не test), итоговая нормализованная
матрица ошибок — по всем flow тестовой выборки.

    python node1_ensemble.py --node 1
    python node1_ensemble.py --node 2
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.metrics import accuracy_score, classification_report, f1_score

from labels_node1 import NODE1_CLASSES as CLS1, CLASS_NAMES_RU as NAMES1
from labels_node2 import NODE1_CLASSES as CLS2, CLASS_NAMES_RU as NAMES2
from node1_lstm_1 import LSTMClassifier as LSTM1, make_sequences as make_seq1, SequenceDataset as SeqDs1, SequenceCollator as SeqColl1
from node1_lstm_2 import LSTMClassifier as LSTM2, make_sequences as make_seq2, SequenceDataset as SeqDs2, SequenceCollator as SeqColl2
from node1_mlp_1 import MLPClassifier as MLP1
from node1_mlp_2 import MLPClassifier as MLP2
from pipeline import get_lstm_probs, get_mlp_probs
from traffic_metrics import normalized_confusion, predictions_per_flow, remove_old_plots
from window_features import aggregate_windows

MODEL_DIR = Path("models")
CAT_COLS = ["Source Port", "Destination Port", "Protocol"]


def model_probabilities(node, frame):
    directory = Path(f"data/processed_node{node}")
    with open(directory / "feature_names.json", encoding="utf-8") as f:
        features = json.load(f)
    with open(MODEL_DIR / f"node1_lgbm_{node}" / "feature_columns.json", encoding="utf-8") as f:
        feat_cols = json.load(f)
    agg = aggregate_windows(frame, [x for x in features if x not in CAT_COLS], CAT_COLS)
    x = np.nan_to_num(agg[feat_cols].to_numpy(dtype=np.float32), nan=0.0, posinf=0.0, neginf=0.0)
    lstm_cls, seq_fn, seq_ds, coll, mlp_cls = {
        1: (LSTM1, make_seq1, SeqDs1, SeqColl1, MLP1),
        2: (LSTM2, make_seq2, SeqDs2, SeqColl2, MLP2),
    }[node]
    lstm = get_lstm_probs(MODEL_DIR / f"node1_lstm_{node}", frame,
                          lstm_cls, seq_fn, seq_ds, coll)
    mlp = get_mlp_probs(MODEL_DIR / f"node1_mlp_{node}", agg, mlp_cls, feat_cols)
    booster = lgb.Booster(model_file=str(MODEL_DIR / f"node1_lgbm_{node}" / "model.txt"))
    tree = np.asarray(booster.predict(x))
    if tree.ndim == 1:
        tree = np.stack([1 - tree, tree], axis=1)
    if not (len(lstm) == len(mlp) == len(tree) == len(agg)):
        raise RuntimeError("Несовпадение количества окон между моделями")
    return agg["window_id"].tolist(), {"BiLSTM": lstm, "MLP": mlp, "LightGBM": tree}


def candidate_predictions(probs, weights):
    names = list(probs)
    arr = np.stack([probs[name] for name in names], axis=0)
    individual = {k: v.argmax(axis=1) for k, v in probs.items()}
    votes = np.stack(list(individual.values()), axis=0)
    n_classes = arr.shape[2]
    hard = np.array([np.bincount(votes[:, i], minlength=n_classes).argmax()
                     for i in range(votes.shape[1])], dtype=np.int64)
    return {**individual,
            "Hard voting": hard,
            "Soft voting": arr.mean(axis=0).argmax(axis=1),
            "Weighted soft": np.average(arr, axis=0, weights=weights).argmax(axis=1)}


def scores(frame, ids, candidates, n_classes):
    results = {}
    for method, y_pred_win in candidates.items():
        yt, yp = predictions_per_flow(frame, ids, y_pred_win)
        results[method] = float(f1_score(yt, yp, labels=list(range(n_classes)),
                                         average="macro", zero_division=0))
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--node", type=int, choices=[1, 2], default=1,
                    help="1: BENIGN/ATTACK; 2: SYN/UDP/LDAP/DNS/OTHER")
    args = ap.parse_args()
    node = args.node
    classes = CLS1 if node == 1 else CLS2
    names = NAMES1 if node == 1 else NAMES2
    directory = Path(f"data/processed_node{node}")
    out_dir = MODEL_DIR / f"node1_ensemble_{node}"
    out_dir.mkdir(parents=True, exist_ok=True)

    val_df = pd.read_parquet(directory / "val.parquet")
    test_df = pd.read_parquet(directory / "test.parquet")
    val_ids, val_probs = model_probabilities(node, val_df)
    test_ids, test_probs = model_probabilities(node, test_df)
    val_individual = scores(val_df, val_ids,
                            {k: p.argmax(axis=1) for k, p in val_probs.items()}, len(classes))
    weights = np.array(list(val_individual.values()), dtype=float)
    if weights.sum() == 0:
        weights[:] = 1.0
    val_methods = candidate_predictions(val_probs, weights)
    val_scores = scores(val_df, val_ids, val_methods, len(classes))
    selected = max(val_scores, key=val_scores.get)

    test_methods = candidate_predictions(test_probs, weights)
    test_scores = scores(test_df, test_ids, test_methods, len(classes))
    yt, yp = predictions_per_flow(test_df, test_ids, test_methods[selected])
    cm = normalized_confusion(yt, yp, names,
        out_dir / f"node1_ensemble_{node}_confusion_matrix_normalized.png",
        f"Узел {node}: ансамбль {selected} — по flow")
    remove_old_plots(out_dir, f"node1_ensemble_{node}")

    plt.figure(figsize=(10, 6))
    plt.bar(list(test_scores), list(test_scores.values()))
    plt.ylim(0, 1.0)
    plt.xticks(rotation=25, ha="right")
    plt.ylabel("Macro-F1 по flow")
    plt.title(f"Узел {node}: сравнение моделей (тест)")
    plt.grid(axis="y", alpha=.3)
    plt.tight_layout()
    plt.savefig(out_dir / f"node1_ensemble_{node}_comparison.png", dpi=160)
    plt.close()
    metrics = {"node": node, "method_selected_on_val": selected,
               "evaluation_unit": "flow", "n_test_flows": len(test_df),
               "n_test_windows": len(test_ids), "classes": classes,
               "validation_macro_f1": val_scores, "test_macro_f1": test_scores,
               "val_weights": dict(zip(val_probs, map(float, weights))),
               "accuracy": float(accuracy_score(yt, yp)),
               "confusion_matrix_counts": cm.tolist()}
    (out_dir / "metrics.json").write_text(json.dumps(metrics, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Узел {node} — выбран по validation: {selected}")
    print(f"Оценено тестовых flow: {len(yt):,}, окон: {len(test_ids):,}")
    print(f"Accuracy={metrics['accuracy']:.4f}, macro-F1={test_scores[selected]:.4f}")
    print(classification_report(yt, yp, labels=list(range(len(classes))),
                                target_names=names, zero_division=0))


if __name__ == "__main__":
    main()
