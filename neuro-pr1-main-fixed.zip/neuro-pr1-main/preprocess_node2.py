#!/usr/bin/env python
"""Данные второго узла (SYN/UDP/LDAP/DNS/OTHER) из разбиения первого узла.

Запускайте после preprocess_node1.py. Вся разметка типов атак сохраняется
для каждого flow. Исключение BENIGN не меняет train/val/test назначение окон.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from labels_node2 import NODE1_CLASSES, CLASS_NAMES_RU

SOURCE_DIR = Path("data/processed_node1")
TARGET_DIR = Path("data/processed_node2")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from-node1", type=Path, default=SOURCE_DIR,
                        help="Каталог parquet первого узла после preprocess_node1.py")
    parser.add_argument("--out", type=Path, default=TARGET_DIR)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    source_info = args.from_node1 / "split_info.json"
    if not source_info.exists():
        parser.error(f"Сначала выполните preprocess_node1.py: отсутствует {source_info}")
    info = json.loads(source_info.read_text(encoding="utf-8"))
    if info.get("classes") != ["BENIGN", "ATTACK"]:
        parser.error("Нужны данные бинарного узла: классы BENIGN, ATTACK")

    seen = {}
    for split in ("train", "val", "test"):
        source = args.from_node1 / f"{split}.parquet"
        df = pd.read_parquet(source)
        if "attack_type" not in df.columns:
            parser.error(f"{source} не содержит attack_type; пересоздайте данные Узла 1")
        attack = df.loc[df["attack_type"] >= 0].copy()
        if attack.empty:
            raise ValueError(f"В {split} нет ни одного атакующего flow")
        if not attack["attack_type"].between(0, len(NODE1_CLASSES) - 1).all():
            raise ValueError(f"Недопустимая метка attack_type в {split}")
        attack["label"] = attack["attack_type"].astype("int64")
        # Переписываем label, но сохраняем порядок строк/окон и идентификаторы источников.
        attack.drop(columns=["attack_type"], inplace=True)
        attack.to_parquet(args.out / f"{split}.parquet", index=False)
        seen[split] = set(attack["window_id"].unique())
        print(f"{split}: {len(attack):,} атакующих flow, {len(seen[split]):,} окон")

    if (seen["train"] & seen["val"]) or (seen["train"] & seen["test"]) or (seen["val"] & seen["test"]):
        raise RuntimeError("Пересечение window_id между train/val/test")

    (args.out / "feature_names.json").write_bytes(
        (args.from_node1 / "feature_names.json").read_bytes())
    (args.out / "medians.json").write_bytes(
        (args.from_node1 / "medians.json").read_bytes())
    (args.out / "split_info.json").write_text(json.dumps({
        "window_seconds": info["window_seconds"],
        "classes": NODE1_CLASSES, "classes_ru": CLASS_NAMES_RU,
        "split_strategy": "same_window_split_as_node1;_attack_flows_only",
        "source_stage": str(args.from_node1),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Готово: {args.out}. Окна и разбиение синхронизированы с Узлом 1")


if __name__ == "__main__":
    main()
